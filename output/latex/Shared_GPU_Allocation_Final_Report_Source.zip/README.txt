Compile FAI_Project_Final_Report.tex with PDFLaTeX, BibTeX and two final PDFLaTeX passes.
The archive includes generated assets and needs no simulator to compile.
Regenerate data and audit assets in the repository with python analysis/build_final_report.py.
Repository: https://github.com/kalpshah18/Shared-GPU-Allocation
